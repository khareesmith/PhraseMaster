from sqlalchemy.ext.declarative import declarative_base

# SQLAlchemy base model
Base = declarative_base()